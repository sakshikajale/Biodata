
$(document).ready(function(){
  $('#नाव, #जन्मतारीख, #जन्म_वेळ, #जन्म_स्थळ, #धर्म_जात, #राशी, #ऊंची, #वर्ण, #शिक्षण, #नोकरी_व्यवसाय, #वेतन_उत्पन्न, #रक्तगट, #वडिलांचे_नाव, #आईचे_नाव, #बहीण, #भाऊ, #मामाचे_नाव_आजोळ, #अपेक्षा, #पत्ता, #मोबाईल_नंबर,#photo').on('input', function(){
    var formData = $('#registrationForm').serialize();
    $('#previewFrame').attr('src', 'p.php?' + formData);
  });
});