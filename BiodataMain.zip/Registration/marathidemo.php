<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <style>

   ./*background {
    background-image: url('template2.jpg');
    background-size: cover;
    background-position: center;
    overflow: hidden;
  }*/
  .preview-container {
    border: 1px solid #ccc; 
    border-radius: 10px; 
    overflow: hidden; 
  }

  .preview-iframe {
    width: 5000px;
    height: 800px; 
    margin-top: 100px;
  }
  .padding{
  padding-bottom: 50px;
  padding-left: 50px;
  padding-right: 50px;
}
  }
  </style>
</head>
    <body style="padding-top: 20px">
      <div class="row">
      <div class="col">
          <div align="center" class="btn-group" role="group" aria-label="Basic example">
           <button type="button" class="btn btn-light"><a href="http://localhost/Registration/Marathidemo.php">Marathi</a></button>
            <button type="button" class="btn btn-light"><a href="http://localhost/Registration/form.php">  English</a></button>
      </div>
      </div>
  <div class="container" style="padding">
    <div class="row">
      <div class="col-6">
   <form id="registrationForm" method="post"action="p.php"  class="row g-3 padding">
    <div class="row text-center">

          <div class="col-4"></div>
          
          <div class="col-4"><img src="img.png"></div>
          <div class="col-4"></div>
        </div>
        <div class="row">
          <div class="col text-center">
            <input type="text" class=" border-0 text-center mt-2 fw-bold"  id="ihh1" value="|| श्री गणेशाय नम: ||" maxlength="70">
          </div>
    
          <div  style="padding-top: 10px" class="row">
            <div class="col-md-6">
              <label for="नाव" class="form-label">नाव:</label>
              <input type="text" id="नाव" name="नाव" class="form-control">
            </div>

            <div class="col-md-6">
              <label for="जन्मतारीख" class="form-label">जन्मतारीख:</label>
              <input type="date" id="जन्मतारीख" name="जन्मतारीख" class="form-control">
            </div>
          </div>

          <div class="row">
            <div class="col-md-6">
              <label for="जन्म वेळ" class="form-label text-end">जन्म वेळ:</label>
              <input type="text" id="जन्म_वेळ" name="जन्म_वेळ" class="form-control">
            </div>

            <div class="col-md-6">
              <label for="जन्म स्थळ" class="form-label text-end">जन्म स्थळ:</label>
              <input type="text" id="जन्म_स्थळ" name="जन्म_स्थळ" class="form-control">     
            </div>
          </div>   

          <div class="row">
            <div class="col-md-6">
              <label for="धर्म जात" class="form-label text-end">धर्म-जात:</label>
              <input type="text" id="धर्म_जात" name="धर्म_जात" class="form-control">
            </div>

            <div class="col-md-6">
              <label for="राशी" class="form-label text-end">राशी:</label>
              <select class="form-select" aria-label="rashi" name="राशी" id="राशी">
                <option value="" selected="">&nbsp;</option>
                <option value="मेष">मेष</option>
                <option value="वृषभ">वृषभ</option>
                <option value="मिथुन">मिथुन</option>
                <option value="कर्क">कर्क</option>
                <option value="सिंह">सिंह</option>
                <option value="कन्या">कन्या</option>
                <option value="तूळ">तूळ</option>
                <option value="वृश्चिक">वृश्चिक</option>
                <option value="धनु">धनु</option>
                <option value="मकर">मकर</option>
                <option value="कुंभ">कुंभ</option>
                <option value="मीन">मीन</option>
              </select>
            </div>
          </div>
                      <div class="row">
            <div class="col-md-6">
              <label for="गोत्र" class="form-label text-end">गोत्र:</label>
              <select class="form-select" id="गोत्र" name="गोत्र">
                <option value="" selected="">&nbsp;</option>
                <option value="कश्यप">कश्यप</option>
                <option value="भारद्वाज">भारद्वाज</option>
                <option value="वशिष्ठ">वशिष्ठ</option>
                <option value="विश्वामित्र">विश्वामित्र</option>
                <option value="गौतम">गौतम</option>
                <option value="अंगिरा">अंगिरा</option>
                <option value="अत्रि">अत्रि</option>
                <option value="क्रतू">क्रतू</option>                            
                <option value="जमदग्नी">जमदग्नी</option>
                <option value="पुलास्ती">पुलास्ती</option>
                <option value="पुलाह">पुलाह</option>                            
                <option value="अगस्त्य">अगस्त्य</option>
                <option value="कौंडिन्य">कौंडिन्य</option>
                <option value="कौशिक">कौशिक</option>
                <option value="गार्ग्य">गार्ग्य</option>
                <option value="दुर्वास">दुर्वास</option>
                <option value="पारेख">पारेख</option>
                <option value="भार्गव">भार्गव</option>
                <option value="भृगु">भृगु</option>
                <option value="शाण्डिल्य">शाण्डिल्य</option>
                <option value="सुपरनस्य">सुपरनस्य</option>
              </select>
            </div>

            <div class="col-md-6">
              <label for="कुलदैवत" class="form-label text-end">कुलदैवत:</label>
              <input type="text" id="कुलदैवत" name="कुलदैवत" class="form-control">     
            </div>
          </div>

          <div class="row">
            <div class="col-md-6">
              <label for="ऊंची" class="form-label text-end">ऊंची:</label>
              <select class="form-select" id="ऊंची"  aria-label="Height" name="ऊंची">
              <option value="" selected="">&nbsp;</option>
              <option value="4 फूट 1 इंच">4 फूट 1 इंच</option>
              <option value="4 फूट 2 इंच">4 फूट 2 इंच</option>
              <option value="4 फूट 3 इंच">4 फूट 3 इंच</option>
              <option value="4 फूट 4 इंच">4 फूट 4 इंच</option>
              <option value="4 फूट 5 इंच">4 फूट 5 इंच</option>
              <option value="4 फूट 6 इंच">4 फूट 6 इंच</option>
              <option value="4 फूट 7 इंच">4 फूट 7 इंच</option>
              <option value="4 फूट 8 इंच">4 फूट 8 इंच</option>
              <option value="4 फूट 9 इंच">4 फूट 9 इंच</option>
              <option value="4 फूट 10 in">4 फूट 10 in</option>
              <option value="4 फूट 11 इंच">4 फूट 11 इंच</option>
              <option value="5 फूट">5 फूट</option>
              <option value="5 फूट 1 इंच">5 फूट 1 इंच</option>
              <option value="5 फूट 2 इंच">5 फूट 2 इंच</option>
              <option value="5 फूट 3 इंच">5 फूट 3 इंच</option>
              <option value="5 फूट 4 इंच">5 फूट 4 इंच</option>
              <option value="5 फूट 5 इंच">5 फूट 5 इंच</option>
              <option value="5 फूट 6 इंच">5 फूट 6 इंच</option>
              <option value="5 फूट 7 इंच">5 फूट 7 इंच</option>
              <option value="5 फूट 8 इंच">5 फूट 8 इंच</option>
              <option value="5 फूट 9 इंच">5 फूट 9 इंच</option>
              <option value="5 फूट 10 इंच">5 फूट 10 इंच</option>
              <option value="5 फूट 11 इंच">5 फूट 11 इंच</option>
              <option value="6 फूट">6 फूट</option>
              <option value="6 फूट 1 इंच">6 फूट 1 इंच</option>
              <option value="6 फूट 2 इंच">6 फूट 2 इंच</option>
              <option value="6 फूट 3 इंच">6 फूट 3 इंच</option>
              <option value="6 फूट 4 इंच">6 फूट 4 इंच</option>
              <option value="6 फूट 5 इंच">6 फूट 5 इंच</option>
              <option value="6 फूट 6 इंच">6 फूट 6 इंच</option>
              <option value="6 फूट 7 इंच">6 फूट 7 इंच</option>
              </select>

            </div>

            <div class="col-md-6">
              <label for="वर्ण" class="form-label text-end">वर्ण:</label>
              <select class="form-select" aria-label="varn" name="वर्ण" id="वर्ण">
                <option value="" selected="">&nbsp;</option>
                <option value="गोरा">गोरा</option>
                <option value="निमगोरा">निमगोरा</option>
                <option value="गव्हाळ">गव्हाळ</option>
                <option value="सावळा">सावळा</option>
                <option value="काळा सावळा">काळा सावळा</option>
              </select>
            </div>
          </div>

          <div class="row">
            <div class="col-md-6">
              <label for="शिक्षण" class="form-label text-end">शिक्षण:</label>
              <input type="text" id="शिक्षण" name="शिक्षण" class="form-control">
            </div>

            <div class="col-md-6">
              <label for="नोकरी व्यवसाय" class="form-label text-end">नोकरी/व्यवसाय:</label>
              <input type="text" id="नोकरी_व्यवसाय" name="नोकरी व्यवसाय" class="form-control">
            </div>
          </div>

          <div class="row">
            <div class="col-md-6">
              <label for="वेतन उत्पन्न" class="form-label text-end">वेतन/उत्पन्न:</label>
              <input type="text" id="वेतन_उत्पन्न" name="वेतन उत्पन्न" class="form-control">
            </div>

            <div class="col-md-6">
              <label for="रक्तगट" class="form-label text-end">रक्तगट:</label>
              <select class="form-select" aria-label="raktgat" name="रक्तगट" id="रक्तगट">
                <option value="" selected="">&nbsp;</option>
                <option value="O+">O+</option>
                <option value="O-">O-</option>
                <option value="A+">A+</option>
                <option value="A-">A-</option>
                <option value="B+">B+</option>
                <option value="B-">B-</option>
                <option value="AB+">AB+</option>
                <option value="AB-">AB-</option>
              </select>
            </div>
          </div>

          <div class="row">
            <div class="col-md-6">
              <label for="वडिलांचे नाव" class="form-label text-end">वडिलांचे नाव:</label>
              <input type="text" id="वडिलांचे_नाव" name="वडिलांचे_नाव" class="form-control">
            </div>

            <div class="col-md-6">
              <label for="आईचे नाव" class="form-label text-end">आईचे नाव:</label>
              <input type="text" id="आईचे_नाव" name="आईचे_नाव" class="form-control">     
            </div>
          </div>

            <div class="row">
            <div class="col-md-6">
              <label for="वडिलांचा व्यवसाय:" class="form-label text-end">वडिलांचा व्यवसाय:</label>
              <input type="text" id="वडिलांचा_व्यवसाय" name="वडिलांचा_व्यवसाय" class="form-control">
            </div>

            <div class="col-md-6">
              <label for="आजोबा" class="form-label text-end">आजोबा:</label>
              <input type="text" id="आजोबा" name="आजोबा" class="form-control">     
            </div>
          </div>


          <div class="row">
            <div class="col-md-6">
              <label for="बहीण" class="form-label text-end">बहीण:</label>
              <input type="text" id="बहीण" name="बहीण" class="form-control">     
            </div>

            <div class="col-md-6">
              <label for="भाऊ" class="form-label text-end">भाऊ:</label>
              <input type="text" id="भाऊ" name="भाऊ" class="form-control">
            </div>
          </div>

          <div class="row">
            <div class="col-md-6">
              <label for="आत्या" class="form-label text-end">आत्या:</label>
              <input type="text" id="आत्या" name="आत्या" class="form-control">
            </div>

            <div class="col-md-6">
              <label for="काका" class="form-label text-end">काका:</label>
              <input type="text" id="काका" name="काका" class="form-control">     
            </div>
          </div>


          <div class="row">
            <div class="col-md-6">
              <label for="मामाचे नाव आजोळ" class="form-label text-end">मामाचे नाव/आजोळ:</label>
              <input type="text" id="मामाचे_नाव_आजोळ" name="मामाचे_नाव_आजोळ" class="form-control">     
            </div>

            <div class="col-md-6">
              <label for="अपेक्षा" class="form-label text-end">अपेक्षा:</label>
              <input type="text" id="अपेक्षा" name="अपेक्षा" class="form-control">
            </div>
          </div>

          <div class="row">
            <div class="col-md-6">
              <label for="नातेसंबंध" class="form-label text-end">नातेसंबंध:</label>
              <input type="text" id="नातेसंबंध" name="नातेसंबंध" class="form-control">     
            </div>

            <div class="col-md-6">
              <label for="येथे अतिरिक्त शीर्षक अ‍ॅड करू शकता" class="form-label text-end">येथे अतिरिक्त शीर्षक अ‍ॅड करू शकता:</label>
              <input type="text" id="येथे अतिरिक्त शीर्षक अ‍ॅड करू शकता" name="येथे अतिरिक्त शीर्षक अ‍ॅड करू शकता" class="form-control">
            </div>
          </div>



          <div class="row">
            <div class="col-md-6">
              <label for="पत्ता" class="form-label text-end">पत्ता:</label>
              <input type="text" id="पत्ता" name="पत्ता" class="form-control">     
            </div>

            <div class="col-md-6">
              <label for="मोबाईल नंबर" class="form-label text-end">मोबाईल नंबर:</label>
              <input type="text" id="मोबाईल_नंबर" name="मोबाईल_नंबर" class="form-control">
            </div>
          </div>

        

            <label for="image">Upload Image:</label>
            <input type="file" id="image" name="image" accept="image/*" required><br><br>

        </div> 
            <button type="button" class="btn btn-dark" id="download">submit</button>
      </form>
    </div>

    <div class="col-6 padding">
      <div class="preview-container p container preview-container background text-center padding">
        <iframe class="preview-iframe" id="previewFrame" frameborder="0" style=" width:200%; height:70;"></iframe>
      </div>
    </div>
  </div>    
</div>
</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="sc.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
 <script type="text/javascript">
$(document).ready(function() {
  $('#registrationForm input, #registrationForm select').on('input', function() {
    var formData = $('#registrationForm').serialize();
    $('#previewFrame').attr('src', 'p.php?' + formData); // Pass form data to the PHP script
  });

  $('#download').on('click', function() {
    var previewFrame = document.getElementById('previewFrame');
    var previewContainer = previewFrame.contentWindow.document.body;

    html2canvas(previewContainer, {
      allowTaint: true,
      useCORS: true
    }).then(function(canvas) {
      var ctx = canvas.getContext('2d');

      // Draw input fields onto the canvas
      previewContainer.querySelectorAll('input, select').forEach(function(input) {
        var inputRect = input.getBoundingClientRect();
        ctx.fillStyle = window.getComputedStyle(input).color;
        ctx.fillRect(inputRect.left, inputRect.top, inputRect.width, inputRect.height);
      });

      var dataURL = canvas.toDataURL('image/jpeg');

      // Create a link to download the image
      var link = document.createElement('a');
      link.href = dataURL;
      link.download = 'preview_with_image.jpeg';
      link.click();

    }).catch(function(error) {
      console.error('Error capturing the canvas:', error);
    });
  });
});
</script>


</body>
</html>

<?php
// Include database connection configuration
require_once('config.php');

// Check if the form is submitted
if(isset($_POST['create'])){
    // Retrieve form data
    $नाव = $_POST['नाव'];
    $जन्मतारीख = $_POST['जन्मतारीख'];
    $जन्म_वेळ = $_POST['जन्म_वेळ'];
    $जन्म_स्थळ = $_POST['जन्म_स्थळ'];
    $धर्म_जात = $_POST['धर्म_जात'];
    $राशी = $_POST['राशी'];
    $गोत्र = $_POST['गोत्र'];
    $कुलदैवत = $_POST['कुलदैवत'];
    $ऊंची = $_POST['ऊंची'];
    $वर्ण = $_POST['वर्ण'];
    $शिक्षण = $_POST['शिक्षण'];
    $नोकरी_व्यवसाय = $_POST['नोकरी_व्यवसाय'];
    $वेतन_उत्पन्न = $_POST['वेतन_उत्पन्न'];
    $रक्तगट = $_POST['रक्तगट'];
    $वडिलांचे_नाव = $_POST['वडिलांचे_नाव'];
    $आईचे_नाव = $_POST['आईचे_नाव'];
    $वडिलांचा_व्यवसाय = $_POST['वडिलांचा_व्यवसाय'];
    $आजोबा = $_POST['आजोबा'];
    $बहीण = $_POST['बहीण'];
    $भाऊ = $_POST['भाऊ'];
    $मामाचे_नाव_आजोळ = $_POST['मामाचे_नाव_आजोळ'];
    $नातेसंबंध = $_POST['नातेसंबंध'];
    $अपेक्षा = $_POST['अपेक्षा'];
    $पत्ता = $_POST['पत्ता'];
    $मोबाईल_नंबर = $_POST['मोबाईल_नंबर'];


    // Prepare SQL query to insert data into user table
    $sql = "INSERT INTO marathi(नाव,जन्मतारीख,जन्म_वेळ,जन्म_स्थळ,धर्म_जात,राशी,गोत्र,कुलदैवत,ऊंची,वर्ण,शिक्षण,नोकरी_व्यवसाय,वेतन_उत्पन्न,रक्तगट,वडिलांचे_नाव,आईचे_नाव,वडिलांचा_व्यवसाय,बहीण,भाऊ,मामाचे_नाव_आजोळ,नातेसंबंध,अपेक्षा,पत्ता,मोबाईल_नंबर) 
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    $stmt = $db->prepare($sql);

    // Bind parameters and execute the statement
    $result = $stmt->execute([$नाव, $जन्मतारीख,$जन्म_वेळ,$जन्म_स्थळ,$धर्म_जात,$राशी,$गोत्र,$कुलदैवत,$ऊंची,$वर्ण,$शिक्षण,$नोकरी_व्यवसाय,$वेतन_उत्पन्न,$रक्तगट,$वडिलांचे_नाव,$आईचे_नाव,$वडिलांचा_व्यवसाय,$बहीण,$भाऊ,$मामाचे_नाव_आजोळ,$नातेसंबंध,$अपेक्षा,$पत्ता,$मोबाईल_नंबर]);

    // Check if the query was successful
    if($result){
        echo "Data inserted successfully.";
    } else {
        echo "Error inserting data.";
    }
}
?>
