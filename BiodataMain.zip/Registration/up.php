<!-- <?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $नाव = $_POST['नाव'];
    $image = $_FILES['image'];
    $background = $_FILES['background'];

    $uploadDir = 'uploads/';
    $uploadedFiles = [];

    if ($image['error'] === 0) {
        $uploadFile = $uploadDir . basename($image['नाव']);
        move_uploaded_file($image['tmp_name'], $uploadFile);
        $uploadedFiles['image'] = $uploadFile;
    }
    echo json_encode([
        'नाव' => $नाव,
        'files' => $uploadedFiles,
    ]);
}
?>
 -->