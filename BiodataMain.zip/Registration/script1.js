
$(document).ready(function(){
  $('#Name, #phone_number, #birth_date,#zodiac_sign, #birth_time, #birth_place, #height,#complexion,#caste, #marital_status,#education, #Profession,#annual_income,#city,#father_name,#mother_name, #relative,#siblings, #photo').on('input', function(){
    var formData = $('#registrationForm').serialize();
    $('#previewFrame').attr('src', 'preview1.php?' + formData);
  });
});
// function previewImage(event) {
//     var input = event.target;
//     var reader = new FileReader();
//     reader.onload = function(){
//         var imgPreview = document.getElementById('imagePreview');
//         imgPreview.src = reader.result;
//         imgPreview.style.display = 'block';
//     };
//     reader.readAsDataURL(input.files[0]);
// }
