<?php
session_start();
$formData = $_SESSION["formData"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Printable View</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .preview-container {
            width: 794px; /* A4 width in pixels */
            height: 1200px; /* A4 height in pixels */
            padding: 20px;
            box-sizing: border-box;
            background-image: url('template2.jpg'); 
            background-size: cover; /* Cover the entire container */
            background-position: center; /* Center the background image */
            position: relative; /* Position the content relative to the container */
            color: #000; /* Text color */
        }
        .content {
            text-align: left; 
            margin-left: 70px;
            margin-top: 120px; 
            margin-bottom: 300px; 
        }
        #imagePreview {
            position: absolute;
            top: 150px;
            right: 0;
            text-align: right; /* Align image preview text to the right */
            margin-right: 70px; /* Add margin to the right */
        }
    </style>
</head>
<body>
    <div class="preview-container">
        <div class="content">
            <p><strong>नाव:</strong> <?php echo $formData["नाव"]; ?></p>
            <p><strong>जन्मतारीख:</strong> <?php echo $formData["जन्मतारीख"]; ?></p>
            <p><strong>जन्म वेळ:</strong> <?php echo $formData["जन्म_वेळ"]; ?></p>
            <p><strong>राशी:</strong> <?php echo $formData["राशी"]; ?></p>
            <p><strong>जन्म स्थळ:</strong> <?php echo $formData["जन्म_स्थळ"]; ?></p>
            <p><strong>धर्म जात:</strong> <?php echo $formData["धर्म_जात"]; ?></p>
            <p><strong>गोत्र:</strong> <?php echo $formData["गोत्र"]; ?></p>
            <p><strong>कुलदैवत:</strong> <?php echo $formData["कुलदैवत"]; ?></p>
            <p><strong>ऊंची:</strong> <?php echo $formData["ऊंची"]; ?></p>
            <p><strong>वर्ण:</strong> <?php echo $formData["वर्ण"]; ?></p>
            <p><strong>शिक्षण:</strong> <?php echo $formData["शिक्षण"]; ?></p>
            <p><strong>नोकरी व्यवसाय:</strong> <?php echo $formData["नोकरी_व्यवसाय"]; ?></p>
            <p><strong>वेतन उत्पन्न:</strong> <?php echo $formData["वेतन_उत्पन्न"]; ?></p>
            <p><strong>रक्तगट:</strong> <?php echo $formData["रक्तगट"]; ?></p>
            <p><strong>वडिलांचे नाव:</strong> <?php echo $formData["वडिलांचे_नाव"]; ?></p>
            <p><strong>आईचे नाव:</strong> <?php echo $formData["आईचे_नाव"]; ?></p>
            <p><strong>वडिलांचा व्यवसाय:</strong> <?php echo $formData["वडिलांचा_व्यवसाय"]; ?></p>
            <p><strong>आजोबा:</strong> <?php echo $formData["आजोबा"]; ?></p>
            <p><strong>बहीण:</strong> <?php echo $formData["बहीण"]; ?></p>
            <p><strong>भाऊ:</strong> <?php echo $formData["भाऊ"]; ?></p>
            <p><strong>आत्या:</strong> <?php echo $formData["आत्या"]; ?></p>
            <p><strong>काका:</strong> <?php echo $formData["काका"]; ?></p>
            <p><strong>मामाचे नाव आजोळ:</strong> <?php echo $formData["मामाचे_नाव_आजोळ"]; ?></p>
            <p><strong>अपेक्षा:</strong> <?php echo $formData["अपेक्षा"]; ?></p>
            <p><strong>नातेसंबंध:</strong> <?php echo $formData["नातेसंबंध"]; ?></p>
            <p><strong>पत्ता:</strong> <?php echo $formData["पत्ता"]; ?></p>
            <p><strong>मोबाईल नंबर:</strong> <?php echo $formData["मोबाईल_नंबर"]; ?></p>

            <div id="imagePreview">
                <img src="<?php echo $formData["image"]; ?>" alt="Uploaded Image" style="max-width: 170px; height: auto;">
            </div>
        </div>
    </div>
</body>
</html>
