$(document).ready(function(){
  // Handle input event for text inputs
  $('#नाव, #जन्मतारीख, #जन्म_वेळ, #जन्म_स्थळ, #धर्म_जात, #राशी, #ऊंची, #वर्ण, #शिक्षण, #नोकरी_व्यवसाय, #वेतन_उत्पन्न, #रक्तगट, #वडिलांचे_नाव, #आईचे_नाव, #बहीण, #भाऊ, #मामाचे_नाव_आजोळ, #अपेक्षा, #पत्ता, #मोबाईल_नंबर').on('input', function(){
    // Get the form data
    var formData = $('#registrationForm').serialize();
    // Pass form data to Marathipreview.php for preview
    $('#previewFrame').attr('src', 'Marathipreview.php?' + formData);
    
    // Update the preview content for text fields
    updatePreview();
  });

  // Function to update the preview content for text fields
  function updatePreview() {
    // Get the values of the text fields
    var नावValue = $('#नाव').val();
    var जन्मतारीखValue = $('#जन्मतारीख').val();
    var जन्म_वेळValue = $('#जन्म_वेळ').val();
    var जन्म_स्थळValue = $('#जन्म_स्थळ').val();
    var धर्म_जातValue = $('#धर्म_जात').val();
    var राशीValue = $('#राशी').val();
    var ऊंचीValue = $('#ऊंची').val();
    var वर्णValue = $('#वर्ण').val();
    var शिक्षणValue = $('#शिक्षण').val();
    var नोकरी_व्यवसायValue = $('#नोकरी_व्यवसाय').val();
    var वेतन_उत्पन्नValue = $('#वेतन_उत्पन्न').val();
    var रक्तगटValue = $('#रक्तगट').val();
    var वडिलांचे_नावValue = $('#वडिलांचे_नाव').val();
    var आईचे_नावValue = $('#आईचे_नाव').val();
    var बहीणValue = $('#बहीण').val();
    var भाऊValue = $('#भाऊ').val();
    var मामाचे_नाव_आजोळValue = $('#मामाचे_नाव_आजोळ').val();
    var अपेक्षाValue = $('#अपेक्षा').val();
    var पत्ताValue = $('#पत्ता').val();
    var मोबाईल_नंबरValue = $('#मोबाईल_नंबर').val();

    // Construct the preview content
    var previewContent = "<h3>Preview:</h3>";
    previewContent += "<p>नाव: " + नावValue + "</p>";
    previewContent += "<p>जन्मतारीख: " + जन्मतारीखValue + "</p>";
    previewContent += "<p>जन्म_वेळ: " + जन्म_वेळValue + "</p>";
    previewContent += "<p>जन्म_स्थळ: " + जन्म_स्थळValue + "</p>";
    previewContent += "<p>धर्म_जात: " + धर्म_जातValue + "</p>";
    previewContent += "<p>राशी: " + राशीValue + "</p>";
    previewContent += "<p>ऊंची: " + ऊंचीValue + "</p>";
    previewContent += "<p>वर्ण: " + वर्णValue + "</p>";
    previewContent += "<p>शिक्षण: " + शिक्षणValue + "</p>";
    previewContent += "<p>नोकरी_व्यवसाय: " + नोकरी_व्यवसायValue + "</p>";
    previewContent += "<p>वेतन_उत्पन्न: " + वेतन_उत्पन्नValue + "</p>";
    previewContent += "<p>रक्तगट: " + रक्तगटValue + "</p>";
    previewContent += "<p>वडिलांचे_नाव: " + वडिलांचे_नावValue + "</p>";
    previewContent += "<p>आईचे_नाव: " + आईचे_नावValue + "</p>";
    previewContent += "<p>बहीण: " + बहीणValue + "</p>";
    previewContent += "<p>भाऊ: " + भाऊValue + "</p>";
    previewContent += "<p>मामाचे_नाव_आजोळ: " + मामाचे_नाव_आजोळValue + "</p>";
    previewContent += "<p>अपेक्षा: " + अपेक्षाValue + "</p>";
    previewContent += "<p>पत्ता: " + पत्ताValue + "</p>";
    previewContent += "<p>मोबाईल_नंबर: " + मोबाईल_नंबरValue + "</p>";

    // Set the content of the preview iframe
    $('#previewFrame').contents().find('body').html(previewContent);
  }

  // Handle file input change event for image preview
  $('#फोटो').on('change', function(event){
    var input = event.target;
    var reader = new FileReader();

    reader.onload = function() {
      var dataURL = reader.result;
      var imagePreview = document.getElementById('imagePreview');
      imagePreview.src = dataURL;
      imagePreview.style.display = 'block'; // Show the image preview
    };

    reader.readAsDataURL(input.files[0]);
  });
});
