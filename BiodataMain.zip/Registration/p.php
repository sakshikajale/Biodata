
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<style>
   body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
  }
  .preview-container {
    width: 794px; /* A4 width in pixels */
    height: 1123px; /* A4 height in pixels */
    padding: 20px;
    box-sizing: border-box;
    background-image: url('template2.jpg'); /* Set background image */
    background-size: cover; /* Cover the entire container */
    background-position: center; /* Center the background image */
     text-align:;
    position: relative; /* Position the content relative to the container */
    color: #000; /* Text color */
  }
  .content {
     text-align: left; /* Center-align text within the content */
    margin-top: 20px; /* Add margin to the top */
    margin-bottom: 20px; /* Add margin to the bottom */
  }
/* {
    font-family: Arial, sans-serif;
  }
  .preview-container {
    width: 794px; 
    height: 1123px; 
    padding: 20px;
    border: 1px solid #ccc;
    box-sizing: border-box;
  }*/
  /* p {
  color: yellow;
}*/
.field {
    margin-left: 150px;
  }
</style>
</head>
<body>
<div class="preview-container content">
  <div style="margin-left: 330px; "><img src="img.png"><br></br>
    <p style="align-content: center;"><b>|| श्री गणेशाय नम: ||</b> </p>
  </div>
  <?php
  if ($_SERVER["REQUEST_METHOD"] == "GET") {
      // Retrieve form data from the URL
      parse_str($_SERVER['QUERY_STRING'], $formData);
      
      // Display the preview
      if (!empty($formData['नाव'])) {
          echo "<p class='field'>नाव: " . $formData['नाव'] . "</p>";
        }
      if (!empty($formData['जन्मतारीख'])) {
          echo "<p class='field'>जन्म तारीख: " . $formData['जन्मतारीख'] . "</p>";
      }
      
      if (!empty($formData['जन्म_वेळ'])) {
          echo "<p class='field'>जन्म वेळ: " . $formData['जन्म_वेळ'] . "</p>";
      }
      if (!empty($formData['जन्म_स्थळ'])) {
          echo "<p class='field'>जन्म स्थळ: " . $formData['जन्म_स्थळ'] . "</p>";
      }
      if (!empty($formData['धर्म_जात'])) {
          echo "<p class='field'>धर्म जात: " . $formData['धर्म_जात'] . "</p>";
      }
      if (!empty($formData['राशी'])) {
          echo "<p class='field'>राशी: " . $formData['राशी'] . "</p>";
      }
      if (!empty($formData['ऊंची'])) {
          echo "<p class='field'>ऊंची: " . $formData['ऊंची'] . "</p>";
      }
      if (!empty($formData['वर्ण'])) {
          echo "<p class='field'>वर्ण: " . $formData['वर्ण'] . "</p>";
      }
       if (!empty($formData['शिक्षण'])) {
          echo "<p class='field'>शिक्षण: " . $formData['शिक्षण'] . "</p>";
      }
      
      if (!empty($formData['नोकरी/व्यवसाय:'])) {
          echo "<p class='field'>नोकरी व्यवसाय:: " . $formData['नोकरी_व्यवसाय:'] . "</p>";
      }
      if (!empty($formData['वेतन/उत्पन्न:'])) {
          echo "<p class='field'>वेतन उत्पन्न: " . $formData['वेतन_उत्पन्न:'] . "</p>";
      }
      if (!empty($formData['रक्तगट:'])) {
          echo "<p class='field'>रक्तगट:: " . $formData['रक्तगट:'] . "</p>";
      }
      if (!empty($formData['वडिलांचे_नाव'])) {
          echo "<p class='field'>वडिलांचे नाव: " . $formData['वडिलांचे_नाव'] . "</p>";
      }
      if (!empty($formData['आईचे_नाव'])) {
          echo "<p class='field'>आईचे नाव: " . $formData['आईचे_नाव'] . "</p>";
      }
      if (!empty($formData['बहीण'])) {
          echo "<p class='field'>बहीण: " . $formData['बहीण'] . "</p>";
      }
      if (!empty($formData['भाऊ'])) {
          echo "<p class='field'>भाऊ: " . $formData['भाऊ'] . "</p>";
      }
      if (!empty($formData['पत्ता'])) {
          echo "<p class='field'>पत्ता: " . $formData['पत्ता'] . "</p>";
      }
      if (!empty($formData['मोबाईल_नंबर'])) {
          echo "<p class='field'>मोबाईल नंबर: " . $formData['मोबाईल_नंबर'] . "</p>";
      }
      
    }
  ?>
</div>
</body>
</html>
