<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <title>Form with Real-time Image Upload Preview</title>
    <style>
     .preview-container {
    border: 1px solid #ccc; 
    border-radius: 10px; 
    overflow: hidden; 
  }

  .preview-iframe {
    width: 5000px;
    height: 800px; 
    margin-top: 100px;
  }
  .padding{
  padding-bottom: 50px;
  padding-left: 50px;
  padding-right: 50px;
}
    </style>
</head>
<body>
    <div class="form-container">
        <form id="registrationForm" enctype="multipart/form-data" method="POST">
            <label for="नाव" class="form-label">नाव:</label>
            <input type="text" id="नाव" name="नाव" class="form-control"><br><br>

            <label for="जन्मतारीख" class="form-label">जन्मतारीख:</label>
            <input type="date" id="जन्मतारीख" name="जन्मतारीख" class="form-control"><br><br>

            
            <label for="राशी" class="form-label text-end">राशी:</label>
            <select class="form-select" aria-label="rashi" name="राशी" id="राशी">
                <option value="" selected="">&nbsp;</option>
                <option value="मेष">मेष</option>
                <option value="वृषभ">वृषभ</option>
                <option value="मिथुन">मिथुन</option>
                <option value="कर्क">कर्क</option>
                <option value="सिंह">सिंह</option>
                <option value="कन्या">कन्या</option>
                <option value="तूळ">तूळ</option>
                <option value="वृश्चिक">वृश्चिक</option>
                <option value="धनु">धनु</option>
                <option value="मकर">मकर</option>
                <option value="कुंभ">कुंभ</option>
                <option value="मीन">मीन</option>
              </select>

            <label for="image">Upload Image:</label>
            <input type="file" id="image" name="image" accept="image/*" required><br><br>
        </form>
    </div>
    <div class="col-6 padding">
      <div class="preview-containertext-center padding">
        <iframe class="preview-iframe" id="previewIframe" frameborder="0" style=" width:200%; height:70;"></iframe>
    </div>

    <script>
        document.getElementById('नाव').addEventListener('input', updatePreview);
        document.getElementById('जन्मतारीख').addEventListener('input', updatePreview);
        document.getElementById('राशी').addEventListener('input', updatePreview);
        // document.getElementById('').addEventListener('input', updatePreview);
        // document.getElementById('').addEventListener('input', updatePreview);
        // document.getElementById('').addEventListener('input', updatePreview);
        // document.getElementById('').addEventListener('input', updatePreview);
        // document.getElementById('').addEventListener('input', updatePreview);
        // document.getElementById('').addEventListener('input', updatePreview);
        // document.getElementById('').addEventListener('input', updatePreview);
        // document.getElementById('').addEventListener('input', updatePreview);
        // document.getElementById('').addEventListener('input', updatePreview);
        // document.getElementById('').addEventListener('input', updatePreview);
        // document.getElementById('').addEventListener('input', updatePreview);
        // document.getElementById('').addEventListener('input', updatePreview);
        // document.getElementById('').addEventListener('input', updatePreview);
        // document.getElementById('').addEventListener('input', updatePreview);
        // document.getElementById('').addEventListener('input', updatePreview);
        // document.getElementById('').addEventListener('input', updatePreview);
        // document.getElementById('').addEventListener('input', updatePreview);
        // document.getElementById('').addEventListener('input', updatePreview);
        // document.getElementById('').addEventListener('input', updatePreview);
        // document.getElementById('').addEventListener('input', updatePreview);
        // document.getElementById('').addEventListener('input', updatePreview);

        document.getElementById('image').addEventListener('change', updatePreview);

        function updatePreview() {
            const form = document.getElementById('registrationForm');
            const iframe = document.getElementById('previewIframe').contentWindow.document;

            const नाव = form.नाव.value;
            const जन्मतारीख = form.जन्मतारीख.value;
            const राशी = form.राशी.value;
         
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;
            // const  = form..value;





            const image = form.image.files[0];

            iframe.open();
            iframe.write(`
                
                <div class="preview-container content" style="height:auto">
                    <p><strong>नाव:</strong> ${नाव}</p>
                    <p><strong>जन्मतारीख:</strong> ${जन्मतारीख}</p>
                    <p><strong>राशी:</strong> ${राशी}</p>
              
                    <p><strong>No image uploaded</strong></p>
                </div>
            `);

            if (image) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const imgData = e.target.result;
                    iframe.body.innerHTML = `
                        <div class="preview-content">
                            <p><strong>नाव:</strong> ${नाव}</p>
                            <p><strong>जन्मतारीख:</strong> ${जन्मतारीख}</p>
                            <p><strong>राशी:</strong> ${राशी}</p>
                           
                            <img src="${imgData}" alt="Uploaded Image" style="max-width: 100px; height: auto;">
                        </div>
                    `;
                };
                reader.readAsDataURL(image);
            }
            iframe.close();
        }

        updatePreview();
    </script>
</body>
</html>
