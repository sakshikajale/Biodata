  <!DOCTYPE html>
<html>
<head>
  <title></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <style>
  .background {
    background-image: url('template3.jpg');
    background-size: cover;
    background-position: center;
  }

  .preview-container {
    border: 1px solid #ccc; /* Add border to the preview container */
    border-radius: 10px; /* Optional: Add border radius for visual appeal */
    overflow: hidden; /* Hide any overflow content */
  }

  .preview-iframe {
    width: 5000px; /* Make the iframe responsive */
    height: 800px; /* Set the height of the iframe */
    margin-top: 100px;
  }
  .padding{
  padding-bottom: 50px;
  padding-left: 50px;
  padding-right: 50px;
}
  }
</style>
</head>
      <body style="padding-top: 50px">
  <div class="container">
    <div class="row">
      <div class="col-6">
         <form id="registrationForm" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" class="row g-3">
         <div class="row text-center">
          <div class="col-4"></div>
          
          <div class="col-4"><img src="img.png"></div>
          <div class="col-4"></div>
        </div>
        <div class="row">
          <div class="col text-center">
            <input type="text" class=" border-0 text-center mt-2 fw-bold" name="hh1" id="ihh1" value="|| श्री गणेशाय नम: ||" maxlength="70">
          </div>

        </div>
          <div  style="padding-top: 10px" class="row">
    <div class="col-md-6">
      <label for="नाव" class="form-label">नाव:</label>
      <input type="text" id="नाव" name="नाव" class="form-control">
    </div>

    <div class="col-md-6">
      <label for="जन्मतारीख" class="form-label">जन्मतारीख:</label>
      <input type="date" id="जन्मतारीख" name="जन्मतारीख" class="form-control">
    </div>
</div>
   <div class="row">
    
    <div class="col-md-6">
      <label for="जन्म वेळ" class="form-label text-end">जन्म वेळ:</label>
      <input type="text" id="जन्म वेळ" name="जन्म वेळ" class="form-control">
    </div>

    <div class="col-md-6">
      <label for="जन्म स्थळ" class="form-label text-end">जन्म स्थळ:</label>
      <input type="text" id="जन्म स्थळ" name="जन्म स्थळ" class="form-control">     
    </div>
</div>

    <div class="row">
    <div class="col-md-6">
      <label for="धर्म-जात" class="form-label text-end">धर्म-जात:</label>
      <input type="text" id="धर्म-जात" name="धर्म-जात" class="form-control">
    </div>
    <div class="col-md-6">
      <label for="राशी" class="form-label text-end">राशी:</label>
      <select class="form-select" aria-label="rashi" name="hd11" id="ihd11">
      <option value="" selected="">&nbsp;</option>
      <option value="मेष">मेष</option>
      <option value="वृषभ">वृषभ</option>
      <option value="मिथुन">मिथुन</option>
      <option value="कर्क">कर्क</option>
      <option value="सिंह">सिंह</option>
      <option value="कन्या">कन्या</option>
      <option value="तूळ">तूळ</option>
      <option value="वृश्चिक">वृश्चिक</option>
      <option value="धनु">धनु</option>
      <option value="मकर">मकर</option>
      <option value="कुंभ">कुंभ</option>
      <option value="मीन">मीन</option>
      </select>
    </div>
  </div>
    <div class="row">
    

    <div class="col-md-6">
      <label for="ऊंची" class="form-label text-end">ऊंची:</label>
      <input type="text" id="ऊंची" name="ऊंची" class="form-control">
    </div>

    <div class="col-md-6">
      <label for="वर्ण" class="form-label text-end">वर्ण:</label>
     <select class="form-select" aria-label="varn" name="hd15" id="ihd15">
      <option value="" selected="">&nbsp;</option>
      <option value="गोरा">गोरा</option>
      <option value="निमगोरा">निमगोरा</option>
      <option value="गव्हाळ">गव्हाळ</option>
      <option value="सावळा">सावळा</option>
      <option value="काळा सावळा">काळा सावळा</option>
      </select>
   </div>
</div>
    <div class="row">
     <div class="col-md-6">
      <label for="शिक्षण" class="form-label text-end">शिक्षण:</label>
      <input type="text" id="शिक्षण" name="शिक्षण" class="form-control">
    </div>

    <div class="col-md-6">
      <label for="नोकरी/व्यवसाय" class="form-label text-end">नोकरी/व्यवसाय:</label>
     <input type="text" id="नोकरी/व्यवसाय" name="नोकरी/व्यवसाय" class="form-control">
    </div>
</div>

    

     <div class="row">
    <div class="col-md-6">
      <label for="वेतन/उत्पन्न" class="form-label text-end">वेतन/उत्पन्न:</label>
      <input type="text" id="वेतन/उत्पन्न" name="वेतन/उत्पन्न" class="form-control">
    </div>

    <div class="col-md-6">
      <label for="रक्तगट" class="form-label text-end">रक्तगट:</label>
      <select class="form-select" aria-label="raktgat" name="hd16" id="ihd16">
      <option value="" selected="">&nbsp;</option>
      <option value="O+">O+</option>
      <option value="O-">O-</option>
      <option value="A+">A+</option>
      <option value="A-">A-</option>
      <option value="B+">B+</option>
      <option value="B-">B-</option>
      <option value="AB+">AB+</option>
      <option value="AB-">AB-</option>
      </select>
    </div>
</div>
  <div class="row">
    
    <div class="col-md-6">
      <label for="वडिलांचे नाव" class="form-label text-end">वडिलांचे नाव:</label>
      <input type="text" id="वडिलांचे नाव" name="वडिलांचे नाव" class="form-control">
    </div>

    <div class="col-md-6">
      <label for="आईचे नाव" class="form-label text-end">आईचे नाव:</label>
      <input type="text" id="आईचे नाव" name="आईचे नाव" class="form-control">     
    </div>
   
</div>


    <div class="row">
    <div class="col-md-6">
      <label for="बहीण" class="form-label text-end">बहीण:</label>
      <input type="text" id="बहीण" name="बहीण" class="form-control">     
    </div>

    <div class="col-md-6">
      <label for="भाऊ" class="form-label text-end">भाऊ:</label>
      <input type="text" id="भाऊ" name="भाऊ" class="form-control">
    </div>
</div>
     <div class="row">
    
    <div class="col-md-6">
      <label for="मामाचे नाव/आजोळ" class="form-label text-end">मामाचे नाव/आजोळ:</label>
      <input type="text" id="मामाचे नाव/आजोळ" name="मामाचे नाव/आजोळ" class="form-control">     
    </div>

    <div class="col-md-6">
      <label for="अपेक्षा" class="form-label text-end">अपेक्षा:</label>
      <input type="text" id="अपेक्षा" name="अपेक्षा" class="form-control">
    </div>
</div>


  <div class="row">
    
    <div class="col-md-6">
      <label for="पत्ता" class="form-label text-end">पत्ता:</label>
      <input type="text" id="पत्ता" name="पत्ता" class="form-control">     
    </div>

    <div class="col-md-6">
      <label for="मोबाईल नंबर" class="form-label text-end">मोबाईल नंबर:</label>
      <input type="text" id="मोबाईल नंबर" name="मोबाईल नंबर" class="form-control">
    </div>
</div>
       <label for="फोटो" class="form-label text-start">फोटो:</label>
        <input type="file" id="फोटो" name="फोटो"><br><br>
        <img id="imagePreview" src="#" alt="Uploaded Image" style="display: none;">  
  
      <button class="btn btn-primary" type="submit" name="create">Submit</button>
        </form>

    </div>
   <div class="col-6 padding">
      <div class="A4 preview-container p container preview-container background text-center padding">
        <iframe class="preview-iframe" id="previewFrame" frameborder="0" style=" width:100%; height:70;"></iframe>

       <!--  <img img id="imagePreview" src="#" class="preview-image" alt="Preview Image"  style=" padding-top:40px width:40%; height:70%;"> -->
         </div>
        </div>
      </div>    
    </div>
  </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="MarathiJs.js"></script>
</body>
</html>

<?php
// Include database connection configuration
require_once('config.php');

// Check if the form is submitted
if(isset($_POST['create'])){
    // Retrieve form data
    $नाव = $_POST['नाव'];
    $जन्मतारीख = $_POST['जन्मतारीख'];
    $जन्म_वेळ = $_POST['जन्म_वेळ'];
    $जन्म_स्थळ = $_POST['जन्म_स्थळ'];
    $धर्म_जात = $_POST['धर्म_जात'];
    $राशी = $_POST['राशी'];
    $ऊंची = $_POST['ऊंची'];
    $वर्ण = $_POST['वर्ण'];
    $शिक्षण = $_POST['शिक्षण'];
    $नोकरी_व्यवसाय = $_POST['नोकरी_व्यवसाय'];
    $वेतन_उत्पन्न = $_POST['वेतन_उत्पन्न'];
    $रक्तगट = $_POST['रक्तगट'];
    $वडिलांचे_नाव = $_POST['वडिलांचे_नाव'];
    $आईचे_नाव = $_POST['आईचे_नाव'];
    $बहीण = $_POST['बहीण'];
    $भाऊ = $_POST['भाऊ'];
    $मामाचे_नाव_आजोळ = $_POST['मामाचे_नाव_आजोळ'];
    $अपेक्षा = $_POST['अपेक्षा'];
    $पत्ता = $_POST['पत्ता'];
    $मोबाईल_नंबर = $_POST['मोबाईल_नंबर'];

    // Prepare SQL query to insert data into your_table_name
    $sql = "INSERT INTO Marathi (नाव, जन्मतारीख, जन्म_वेळ, जन्म_स्थळ, धर्म_जात, राशी, ऊंची, वर्ण, शिक्षण, नोकरी_व्यवसाय, वेतन_उत्पन्न, रक्तगट, वडिलांचे_नाव, आईचे_नाव, बहीण, भाऊ, मामाचे_नाव_आजोळ, अपेक्षा, पत्ता, मोबाईल_नंबर) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $db->prepare($sql);

    // Bind parameters and execute the statement
    $result = $stmt->execute([$नाव, $जन्मतारीख, $जन्म_वेळ, $जन्म_स्थळ, $धर्म_जात, $राशी, $ऊंची, $वर्ण, $शिक्षण, $नोकरी_व्यवसाय, $वेतन_उत्पन्न, $रक्तगट, $वडिलांचे_नाव, $आईचे_नाव, $बहीण, $भाऊ, $मामाचे_नाव_आजोळ, $अपेक्षा, $पत्ता, $मोबाईल_नंबर]);

    // Check if the query was successful
    if($result){
        echo "Data inserted successfully.";
    } else {
        echo "Error inserting data.";
    }
}
?>
