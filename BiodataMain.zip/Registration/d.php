<!DOCTYPE html>
<html>
<head>
  <title>Responsive Form</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <style>
    .preview-container {
      border: 1px solid #ccc; 
      border-radius: 10px; 
      overflow: hidden; 
    }

    .preview-iframe {
      width: 100%;
      height: 800px; 
      margin-top: 20px;
    }

    .padding {
      padding-bottom: 50px;
    }
  </style>
</head>
<body style="padding-top: 50px">
  <div class="container">
    <div class="row">
      <div class="col-lg-6 col-md-12">
        <form id="registrationForm" method="post" action="p.php" class="row g-3">
          <div class="row text-center">
            <div class="col-12">
              <img src="img.png" class="img-fluid">
            </div>
          </div>
          <div class="row text-center">
            <div class="col-12">
              <input type="text" class="border-0 text-center mt-2 fw-bold" id="ihh1" value="|| श्री गणेशाय नम: ||" maxlength="70">
            </div>
          </div>
          <div class="row g-3">
            <div class="col-md-6">
              <label for="नाव" class="form-label">नाव:</label>
              <input type="text" id="नाव" name="नाव" class="form-control">
            </div>
            <div class="col-md-6">
              <label for="जन्मतारीख" class="form-label">जन्मतारीख:</label>
              <input type="date" id="जन्मतारीख" name="जन्मतारीख" class="form-control">
            </div>
            <div class="col-md-6">
              <label for="जन्म_वेळ" class="form-label">जन्म वेळ:</label>
              <input type="text" id="जन्म_वेळ" name="जन्म_वेळ" class="form-control">
            </div>
            <div class="col-md-6">
              <label for="जन्म_स्थळ" class="form-label">जन्म स्थळ:</label>
              <input type="text" id="जन्म_स्थळ" name="जन्म_स्थळ" class="form-control">
            </div>
            <div class="col-md-6">
              <label for="धर्म_जात" class="form-label">धर्म-जात:</label>
              <input type="text" id="धर्म_जात" name="धर्म_जात" class="form-control">
            </div>
            <div class="col-md-6">
              <label for="राशी" class="form-label">राशी:</label>
              <select class="form-select" aria-label="rashi" name="राशी" id="राशी">
                <option value="" selected="">&nbsp;</option>
                <option value="मेष">मेष</option>
                <option value="वृषभ">वृषभ</option>
                <option value="मिथुन">मिथुन</option>
                <option value="कर्क">कर्क</option>
                <option value="सिंह">सिंह</option>
                <option value="कन्या">कन्या</option>
                <option value="तूळ">तूळ</option>
                <option value="वृश्चिक">वृश्चिक</option>
                <option value="धनु">धनु</option>
                <option value="मकर">मकर</option>
                <option value="कुंभ">कुंभ</option>
                <option value="मीन">मीन</option>
              </select>
            </div>
            <div class="col-md-6">
              <label for="ऊंची" class="form-label">ऊंची:</label>
              <input type="text" id="ऊंची" name="ऊंची" class="form-control">
            </div>
            <div class="col-md-6">
              <label for="वर्ण" class="form-label">वर्ण:</label>
              <select class="form-select" aria-label="varn" name="वर्ण" id="वर्ण">
                <option value="" selected="">&nbsp;</option>
                <option value="गोरा">गोरा</option>
                <option value="निमगोरा">निमगोरा</option>
                <option value="गव्हाळ">गव्हाळ</option>
                <option value="सावळा">सावळा</option>
                <option value="काळा सावळा">काळा सावळा</option>
              </select>
            </div>
            <div class="col-md-6">
              <label for="शिक्षण" class="form-label">शिक्षण:</label>
              <input type="text" id="शिक्षण" name="शिक्षण" class="form-control">
            </div>
            <div class="col-md-6">
              <label for="नोकरी_व्यवसाय" class="form-label">नोकरी/व्यवसाय:</label>
              <input type="text" id="नोकरी_व्यवसाय" name="नोकरी_व्यवसाय" class="form-control">
            </div>
            <div class="col-md-6">
              <label for="वेतन_उत्पन्न" class="form-label">वेतन/उत्पन्न:</label>
              <input type="text" id="वेतन_उत्पन्न" name="वेतन_उत्पन्न" class="form-control">
            </div>
            <div class="col-md-6">
              <label for="रक्तगट" class="form-label">रक्तगट:</label>
              <select class="form-select" aria-label="raktgat" name="रक्तगट" id="रक्तगट">
                <option value="" selected="">&nbsp;</option>
                <option value="O+">O+</option>
                <option value="O-">O-</option>
                <option value="A+">A+</option>
                <option value="A-">A-</option>
                <option value="B+">B+</option>
                <option value="B-">B-</option>
                <option value="AB+">AB+</option>
                <option value="AB-">AB-</option>
              </select>
            </div>
            <div class="col-md-6">
              <label for="वडिलांचे_नाव" class="form-label">वडिलांचे नाव:</label>
              <input type="text" id="वडिलांचे_नाव" name="वडिलांचे_नाव" class="form-control">
            </div>
            <div class="col-md-6">
              <label for="आईचे_नाव" class="form-label">आईचे नाव:</label>
              <input type="text" id="आईचे_नाव" name="आईचे_नाव" class="form-control">
            </div>
            <div class="col-md-6">
              <label for="बहीण" class="form-label">बहीण:</label>
              <input type="text" id="बहीण" name="बहीण" class="form-control">
            </div>
            <div class="col-md-6">
              <label for="भाऊ" class="form-label">भाऊ:</label>
              <input type="text" id="भाऊ" name="भाऊ" class="form-control">
            </div>
            <div class="col-md-6">
              <label for="मामाचे_नाव_आजोळ" class="form-label">मामाचे नाव/आजोळ:</label>
              <input type="text" id="मामाचे_नाव_आजोळ" name="मामाचे_नाव_आजोळ" class="form-control">
            </div>
            <div class="col-md-6">
              <label for="अपेक्षा" class="form-label">अपेक्षा:</label>
              <input type="text" id="अपेक्षा" name="अपेक्षा" class="form-control">
            </div>
            <div class="col-md-6">
              <label for="दुसरे_विशेष" class="form-label">दुसरे विशेष:</label>
              <input type="text" id="दुसरे_विशेष" name="दुसरे_विशेष" class="form-control">
            </div>
            <div class="col-md-6">
              <label for="पत्ता" class="form-label">पत्ता:</label>
              <textarea id="पत्ता" name="पत्ता" class="form-control"></textarea>
            </div>
            <div class="col-md-6">
              <label for="संपर्क_क्रमांक" class="form-label">संपर्क क्रमांक:</label>
              <input type="text" id="संपर्क_क्रमांक" name="संपर्क_क्रमांक" class="form-control">
            </div>
            <div class="col-12 text-center">
              <button type="submit" class="btn btn-primary mt-3">Submit</button>
            </div>
          </div>
        </form>
      </div>
      <div class="col-lg-6 col-md-12 preview-container padding">
        <iframe id="myiframe" name="myiframe" class="preview-iframe"></iframe>
      </div>
    </div>
  </div>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="sc.js"></script>
 <script type="text/javascript">
$(document).ready(function() {
  $('#registrationForm input, #registrationForm select').on('input', function() {
    var formData = $('#registrationForm').serialize();
    $('#previewFrame').attr('src', 'p.php?' + formData); // Pass form data to the PHP script
  });

  $('#download').on('click', function() {
    var previewFrame = document.getElementById('previewFrame');
    var previewContainer = previewFrame.contentWindow.document.body;

    html2canvas(previewContainer, {
      allowTaint: true,
      useCORS: true
    }).then(function(canvas) {
      var ctx = canvas.getContext('2d');

      // Draw input fields onto the canvas
      previewContainer.querySelectorAll('input, select').forEach(function(input) {
        var inputRect = input.getBoundingClientRect();
        ctx.fillStyle = window.getComputedStyle(input).color;
        ctx.fillRect(inputRect.left, inputRect.top, inputRect.width, inputRect.height);
      });

      var dataURL = canvas.toDataURL('image/jpeg');

      // Create a link to download the image
      var link = document.createElement('a');
      link.href = dataURL;
      link.download = 'preview_with_image.jpeg';
      link.click();

    }).catch(function(error) {
      console.error('Error capturing the canvas:', error);
    });
  });
});
</script>

</body>
</html>
