<?php
// Include database connection configuration
require_once('config.php');

// Check if the form is submitted
if(isset($_POST['create'])){
    // Retrieve form data (sanitize if necessary)
    $नाव = $_POST['नाव'];
    $जन्मतारीख = $_POST['जन्मतारीख'];
    $जन्म_वेळ = $_POST['जन्म_वेळ'];
    $जन्म_स्थळ = $_POST['जन्म_स्थळ'];
    $धर्म_जात = $_POST['धर्म_जात'];
    $राशी = $_POST['राशी'];
    $गोत्र = $_POST['गोत्र'];
    $कुलदैवत = $_POST['कुलदैवत'];
    $ऊंची = $_POST['ऊंची'];
    $वर्ण = $_POST['वर्ण'];
    $शिक्षण = $_POST['शिक्षण'];
    $नोकरी_व्यवसाय = $_POST['नोकरी_व्यवसाय'];
    $वेतन_उत्पन्न = $_POST['वेतन_उत्पन्न'];
    $रक्तगट = $_POST['रक्तगट'];
    $वडिलांचे_नाव = $_POST['वडिलांचे_नाव'];
    $आईचे_नाव = $_POST['आईचे_नाव'];
    $वडिलांचा_व्यवसाय = $_POST['वडिलांचा_व्यवसाय'];
    $बहीण = $_POST['बहीण'];
    $भाऊ = $_POST['भाऊ'];
    $मामाचे_नाव_आजोळ = $_POST['मामाचे_नाव_आजोळ'];
    $नातेसंबंध = $_POST['नातेसंबंध'];
    $अपेक्षा = $_POST['अपेक्षा'];
    $पत्ता = $_POST['पत्ता'];
    $मोबाईल_नंबर = $_POST['मोबाईल_नंबर'];

    // File upload handling
    $targetDir = "uploads/";
    $targetFile = $targetDir . basename($_FILES["image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Check if image file is a actual image or fake image
    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if($check === false) {
        echo "File is not an image.";
        $uploadOk = 0;
    }

    // Check if file already exists
    if (file_exists($targetFile)) {
        echo "Sorry, file already exists.";
        $uploadOk = 0;
    }

    // Check file size
    if ($_FILES["image"]["size"] > 500000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    // Allow certain file formats
    $allowedFormats = array("jpg", "jpeg", "png", "gif");
    if(!in_array($imageFileType, $allowedFormats)) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    // if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
            echo "The file ". basename( $_FILES["image"]["name"]). " has been uploaded.";
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }

    // Prepare SQL query to insert data into user table
    $sql = "INSERT INTO user (नाव,जन्मतारीख,जन्म_वेळ,जन्म_स्थळ,धर्म_जात,राशी,गोत्र,कुलदैवत,ऊंची,वर्ण,शिक्षण,नोकरी_व्यवसाय,वेतन_उत्पन्न,रक्तगट,वडिलांचे_नाव,आईचे_नाव,वडिलांचा_व्यवसाय,बहीण,भाऊ,मामाचे_नाव_आजोळ,नातेसंबंध,अपेक्षा,पत्ता,मोबाईल_नंबर,image) 
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    $stmt = $db->prepare($sql);

    // Bind parameters and execute the statement
    $result = $stmt->execute([$नाव, $जन्मतारीख, $जन्म_वेळ, $जन्म_स्थळ, $धर्म_जात, $राशी, $गोत्र, $कुलदैवत, $ऊंची, $वर्ण, $शिक्षण, $नोकरी_व्यवसाय, $वेतन_उत्पन्न, $रक्तगट, $वडिलांचे_नाव, $आईचे_नाव, $वडिलांचा_व्यवसाय, $बहीण, $भाऊ, $मामाचे_नाव_आजोळ, $नातेसंबंध, $अपेक्षा, $पत्ता, $मोबाईल_नंबर, $targetFile]);

    // Check if the query was successful
    if($result){
        echo "Data inserted successfully.";
    } else {
        echo "Error inserting data: ";
        var_dump($stmt->errorInfo()); // Show detailed error information
    }
}
?>
