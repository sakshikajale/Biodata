<!-- <!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Preview</title>
   
<style>
  body {
    font-family: Arial, sans-serif;
  }
  .preview-container {
    width: 794px; /* A4 width in pixels */
    height: 1123px; /* A4 height in pixels */
    padding: 20px;
    border: 1px solid #ccc;
    box-sizing: border-box;
  }
</style>
</head>
<body>
<div class="preview-container">
  <h3>Preview:</h3>
  <?php
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
      // Retrieve form data from the $_POST array
      $नाव = $_POST['नाव'];
      $जन्मतारीख = $_POST['जन्मतारीख'];
      $जन्म_वेळ = $_POST['जन्म_वेळ'];
      $जन्म_स्थळ = $_POST['जन्म_स्थळ'];
      $धर्म_जात = $_POST['धर्म_जात'];
      $राशी = $_POST['राशी'];
      $ऊंची = $_POST['ऊंची'];
      $वर्ण = $_POST['वर्ण'];
      $शिक्षण = $_POST['शिक्षण'];
      $नोकरी_व्यवसाय = $_POST['नोकरी_व्यवसाय'];
      $वेतन_उत्पन्न = $_POST['वेतन_उत्पन्न'];
      $रक्तगट = $_POST['रक्तगट'];
      $वडिलांचे_नाव = $_POST['वडिलांचे_नाव'];
      $आईचे_नाव = $_POST['आईचे_नाव'];
      $बहीण = $_POST['बहीण'];
      $भाऊ = $_POST['भाऊ'];
      $मामाचे_नाव_आजोळ = $_POST['मामाचे_नाव_आजोळ'];
      $अपेक्षा = $_POST['अपेक्षा'];
      $पत्ता = $_POST['पत्ता'];
      $मोबाईल_नंबर = $_POST['मोबाईल_नंबर'];

      // Display the preview
      echo "<p>नाव: " . $नाव . "</p>";
      echo "<p>जन्मतारीख: " . $जन्मतारीख . "</p>";
      echo "<p>जन्म वेळ: " . $जन्म_वेळ . "</p>";
      echo "<p>जन्म स्थळ: " . $जन्म_स्थळ . "</p>";
      echo "<p>धर्म-जात: " . $धर्म_जात . "</p>";
      echo "<p>राशी: " . $राशी . "</p>";
      echo "<p>ऊंची: " . $ऊंची . "</p>";
      echo "<p>वर्ण: " . $वर्ण . "</p>";
      echo "<p>शिक्षण: " . $शिक्षण . "</p>";
      echo "<p>नोकरी/व्यवसाय: " . $नोकरी_व्यवसाय . "</p>";
      echo "<p>वेतन/उत्पन्न: " . $वेतन_उत्पन्न . "</p>";
      echo "<p>रक्तगट: " . $रक्तगट . "</p>";
      echo "<p>वडिलांचे नाव: " . $वडिलांचे_नाव . "</p>";
      echo "<p>आईचे नाव: " . $आईचे_नाव . "</p>";
      echo "<p>बहीण: " . $बहीण . "</p>";
      echo "<p>भाऊ: " . $भाऊ . "</p>";
      echo "<p>मामाचे नाव/आजोळ: " . $मामाचे_नाव_आजोळ . "</p>";
      echo "<p>अपेक्षा: " . $अपेक्षा . "</p>";
      echo "<p>पत्ता: " . $पत्ता . "</p>";
      echo "<p>मोबाईल नंबर: " . $मोबाईल_नंबर . "</p>";
  }
  ?>
</div>
</body>
</html>
 -->