 <!DOCTYPE html>
<html>
<head>
  <title></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <style>
  .background {
    background-image: url('template.jpeg');
    background-size: cover;
    background-position: center;
  }

  .preview-container {
    border: 1px solid #ccc; /* Add border to the preview container */
    border-radius: 10px; /* Optional: Add border radius for visual appeal */
    overflow: hidden; /* Hide any overflow content */
  }

  .preview-iframe {
    width: 5000px; /* Make the iframe responsive */
    height: 800px; /* Set the height of the iframe */
    margin-top: 100px;
  }
  .padding{
  padding-bottom: 50px;
  padding-left: 50px;
  padding-right: 50px;
}
  }
</style>
</head>
      <body style="padding-top: 100px">
  <div class="container">
    <div class="row">
      <div class="col-6">
         <form id="registrationForm" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" class="row g-3">
          <div class="row">
    <div class="col-md-6">
      <label for="Name" class="form-label">Name:</label>
      <input type="text" id="Name" name="Name" class="form-control">
    </div>

    <div class="col-md-6">
      <label for="phone_number" class="form-label">Phone Number:</label>
      <input type="text" id="phone_number" name="phone_number" class="form-control">
    </div>
</div>
   <div class="row">
    
    <div class="col-md-6">
      <label for="birth_date" class="form-label text-end">Birth Date:</label>
      <input type="date" id="birth_date" name="birth_date" class="form-control">
    </div>

    <div class="col-md-6">
      <label for="zodiac_sign" class="form-label text-end">Zodiac Sign :</label>
      <input type="text" id="zodiac_sign" name="zodiac_sign" class="form-control">     
    </div>
</div>

    <div class="row">
    <div class="col-md-6">
      <label for="birth_place" class="form-label text-end">Birth Place:</label>
      <input type="text" id="birth_place" name="birth_place" class="form-control">
    </div>
    <div class="col-md-6">
      <label for="birth_time" class="form-label text-end">Birth Time:</label>
      <input type="text" id="birth_time" name="birth_time" class="form-control">
    </div>
  </div>
    <div class="row">
    

    <div class="col-md-6">
      <label for="height" class="form-label text-end">Height:</label>
      <input type="text" id="height" name="height" class="form-control">
    </div>

    <div class="col-md-6">
      <label for="complexion" class="form-label text-end">Complexion:</label>
     <input type="text" id="complexion" name="complexion" class="form-control">
   </div>
</div>
    <div class="row">
     <div class="col-md-6">
      <label for="caste" class="form-label text-end">Caste:</label>
      <input type="text" id="caste" name="caste" class="form-control">
    </div>

    <div class="col-md-6">
      <label for="marital_status" class="form-label text-end">Marital Status:</label>
      <select id="marital_status" name="marital_status" class="form-select">
        <option value="single">Single</option>
        <option value="married">Married</option>
        <option value="divorced">Divorced</option>
      </select>
    </div>
</div>

    <div class="row">
    
    <div class="col-md-6">
      <label for="education" class="form-label text-end">Education:</label>
      <input type="text" id="education" name="education" class="form-control">
    </div>

    <div class="col-md-6">
      <label for="Profession" class="form-label text-end">Profession:</label>
      <input type="text" id="Profession" name="Profession" class="form-control">     
    </div>
</div>

    <div class="row">
    <div class="col-md-6">
      <label for="city" class="form-label text-end">City:</label>
      <input type="text" id="city" name="city" class="form-control">
    </div>

    <div class="col-md-6">
      <label for="annual_income" class="form-label text-end">Annual Income:</label>
      <input type="text" id="annual_income" name="annual_income" class="form-control">
    </div>
</div>


    <div class="row">
    <div class="col-md-6">
      <label for="father_name" class="form-label text-end">Father Name:</label>
      <input type="text" id="father_name" name="father_name" class="form-control">     
    </div>

    <div class="col-md-6">
      <label for="mother_name" class="form-label text-end">Mother Name:</label>
      <input type="text" id="mother_name" name="mother_name" class="form-control">
    </div>
</div>
    
  <div class="row">
    
    <div class="col-md-6">
      <label for="siblings" class="form-label text-end">Siblings:</label>
      <input type="text" id="siblings" name="siblings" class="form-control">
    </div>

    <div class="col-md-6">
      <label for="relative" class="form-label text-end">Relative:</label>
      <input type="text" id="relative" name="relative" class="form-control">     
    </div>
</div>
       <label for="photo" class="form-label text-start">Photo:</label>
        <input type="file" id="photo" name="photo"><br><br>
        <img id="imagePreview" src="#" alt="Uploaded Image" style="display: none;">  
  
      <button class="btn btn-primary" type="submit" name="create">Submit</button>
        </form>

    </div>
   <div class="col-6 padding">
      <div class="A4 preview-container p container preview-container background text-center padding">
        <iframe class="preview-iframe" id="previewFrame" frameborder="0" style=" width:100%; height:70;"></iframe>

       <!--  <img img id="imagePreview" src="#" class="preview-image" alt="Preview Image"  style=" padding-top:40px width:40%; height:70%;"> -->
         </div>
        </div>
      </div>    
    </div>
  </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="script1.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      document.getElementById('imageInput').addEventListener('change', function(event) {
        var input = event.target;
        var reader = new FileReader();

        reader.onload = function() {
          var dataURL = reader.result;
          var imagePreview = document.getElementById('imagePreview');
          imagePreview.src = dataURL;
        };

        reader.readAsDataURL(input.files[0]);
      });
    });
</body>
</html>

<?php
// Include database connection configuration
require_once('config.php');

// Check if the form is submitted
if(isset($_POST['create'])){
    // Retrieve form data
    $Name = $_POST['Name'];
    $phone_number = $_POST['phone_number'];
    $birth_date = $_POST['birth_date'];
    $zodiac_sign = $_POST['zodiac_sign'];
    $birth_place = $_POST['birth_place'];
    $birth_time = $_POST['birth_time'];
    $height = $_POST['height'];
    $complexion = $_POST['complexion'];
    $caste = $_POST['caste'];
    $marital_status = $_POST['marital_status'];
    $education = $_POST['education'];
    $Profession = $_POST['Profession'];
    $city = $_POST['city'];
    $annual_income = $_POST['annual_income'];
    $father_name = $_POST['father_name'];
    $mother_name = $_POST['mother_name'];
    $siblings = $_POST['siblings'];
    $relative = $_POST['relative'];
    
    // Check if the 'photo' key exists in the $_FILES array
    if(isset($_FILES['photo'])) {
        // Get the photo details
        $photo = $_FILES['photo']['name'];
        $photo_tmp = $_FILES['photo']['tmp_name'];

        // Move the uploaded photo to a directory (e.g., uploads)
        move_uploaded_file($photo_tmp, "uploads/" . $photo);
    } else {
        // Handle the case where the photo is not uploaded
        $photo = ''; // or any default value you prefer
    }

    // Prepare SQL query to insert data into user table
    $sql = "INSERT INTO user (Name, phone_number, birth_date, zodiac_sign, birth_place, birth_time, height, complexion, caste, marital_status, education, Profession, city, annual_income, father_name, mother_name, siblings, relative, photo) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $db->prepare($sql);

    // Bind parameters and execute the statement
    $result = $stmt->execute([$Name, $phone_number, $birth_date, $zodiac_sign, $birth_place, $birth_time, $height, $complexion, $caste, $marital_status, $education, $Profession, $city, $annual_income, $father_name, $mother_name, $siblings, $relative, $photo]);

    // Check if the query was successful
    if($result){
        echo "Data inserted successfully.";
    } else {
        echo "Error inserting data.";
    }
}
?>
