<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Image Preview and Download</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <!-- Custom CSS -->
  <style>
    .preview-container {
      border: 1px solid #ccc;
      border-radius: 10px;
      overflow: hidden;
    }
    .preview-iframe {
      width: 100%;
      height: 800px; /* Adjust height as needed */
      margin-top: 20px;
    }
    .align-left {
    float: left;
    /* Alternatively, you can use text-align: right; if the iframe is within a block element */
}

    .passport-photo {
      width: 150px;
      height: 150px;
      object-fit: cover;
      display: block;
      margin-left: auto;
      margin-right: auto;
    }

  

@media (min-width: 768px) {
    .align-left {
        float: left; /* Align left on larger screens */
    }
}

  </style>
</head>
<body style="padding-top: 20px;">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <form id="uploadForm">
          <div class="mb-3">
            <label for="photo" class="form-label">Upload Photo:</label>
            <input type="file" id="photo" name="photo" class="form-control" >
<img id="imagePreview" src="#" alt="Uploaded Image"  style="width: 50px; height: auto;">
          </div>
          <button type="button" class="btn btn-dark mt-3" id="download">Download Preview</button>
        </form>
      </div>
      <div class="col-md-6">
        <div class="preview-container text-center">
<iframe class="preview-iframe align-right" id="previewFrame"  frameborder="0" ></iframe>
        </div>
      </div>
    </div>
  </div>

  <!-- jQuery -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <!-- html2canvas -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
  <script>
    $(document).ready(function() {
      $('#photo').on('change', function() {
        var file = this.files[0];
        if (file) {
          var reader = new FileReader();
          reader.onload = function(e) {
            $('#imagePreview').attr('src', e.target.result).removeClass('d-none');
            updateIframe(e.target.result);
          }
          reader.readAsDataURL(file);
        }
      });

      function updateIframe(imageUrl) {
        var iframe = $('#previewFrame')[0];
        var doc = iframe.contentDocument || iframe.contentWindow.document;
        doc.open();
          doc.write('<html><head><style>body { text-align: right; }</style></head><body><img src="' + imageUrl + '" class="passport-photo" style="width: 100px; height: auto;"></body></html>');
        doc.close();
      }

      $('#download').on('click', function() {
        var previewFrame = document.getElementById('previewFrame');
        var previewContainer = previewFrame.contentDocument.body;

        html2canvas(previewContainer, {
          allowTaint: true,
          useCORS: true
        }).then(function(canvas) {
          var dataURL = canvas.toDataURL('image/jpeg');
          var link = document.createElement('a');
          link.href = dataURL;
          link.download = 'preview_with_image.jpeg';
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        }).catch(function(error) {
          console.error('Error capturing the canvas:', error);
        });
      });
    });
  </script>
</body>
</html>
