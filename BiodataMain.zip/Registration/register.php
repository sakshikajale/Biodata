
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = $_POST['name'];
  $email = $_POST['email'];
  $photo = $_FILES['profile_photo'];

  // Save the uploaded photo
  $upload_dir = 'uploads/';
  $photo_name = uniqid() . '_' . $photo['name'];
  $photo_path = $upload_dir . $photo_name;
  move_uploaded_file($photo['tmp_name'], $photo_path);

  // Save other form data to the database or perform other actions
  // ...

  // Redirect or display a success message
  header('Location: success.php');
  exit;
}